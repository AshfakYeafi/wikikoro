# Install Package
Install Package with pip

```sh
pip install wikikoro
```
Run the Package

```sh
from wikikoro import wiki
```

```sh
wiki.find("Albart Einsteins")
```